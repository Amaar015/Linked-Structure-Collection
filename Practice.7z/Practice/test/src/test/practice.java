package test;


interface stack{
	public void push(Object obj);
	public Object peek();
	public Object pop();
	public int size();
	public boolean Isempty();
	public Object bottomElement();
	public Object SecondElement();
	public boolean removeFirst();
	public boolean removeSecond();
	public String toString();
}

public class practice implements stack{
	private node top;
	private int size;
	class node{
		node next;
		Object obj;
		node(){
			next=this;
			obj=this;
		}
		node(Object obj){
			this.obj=obj;
		}
		node(Object obj, node next){
			this.obj=obj;
			this.next=next;
		}
	}
	
	practice (){
		top=null;
		size=0;
	}
	
	public void push(Object obj) {
		if(obj==null)
		{	return;
		}
		size++;
		top=new node(obj,top);
	}
	public Object peek() {
		if(size==0)
			throw new IllegalStateException();
	    return top.obj;
	
	}
	public Object pop() {
		if(size==0)
			throw new IllegalStateException();
	Object obj=top.obj;
	top=top.next;

	size--;
	return obj;
	}
public int size() {
	return size;
}
public boolean Isempty()
{
	return (size()==0);
}

public Object bottomElement() {
	if(size==0)
		throw new IllegalStateException();
	    node p=null;
	    for(p=top; p!=null; p=p.next) {
	    	
	    }
	    return p.obj;
}
public Object SecondElement() {
	if(size<3)
		throw new IllegalStateException();
	node p=null;
	for(p=top; p!=null;p=p.next) {
		
	}
	
}
public String toString() {
	
	String s="";
	node p=top;
	while(p!=null) {
		if(p.next!=null)
			s+= p.obj+", ";
		else 
			s+= p.obj;
		p=p.next;	
	}
	
	return "["+s+"]";
}



	
	public static void main(String arg[]) {
	practice stack=new practice()	;
	stack.push("Amaar");
	stack.push("Kashif");
	stack.push("Ali");
	stack.push("Ahmed");
	System.out.println("Size is "+stack.size());
     System.out.println(stack.toString());
//	stack.removeFirst();
//	stack.removeSecond();
////	System.out.println( stack.bottomElement());
	stack.pop();
	System.out.println("Size is "+stack.size());
//	 System.out.println(stack.toString());
	}

}



