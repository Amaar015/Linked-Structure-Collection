package test;


public class mids {
	
		public static void main(String[] args){
			int array[] = {25, 26, 27, 28, 29, 30, 32};
			int search =30;
			int low = 0;
			int high = array.length-1;
			int mid;
			while(low<=high){
				mid = (low+high)/2;
				System.out.println("Here search item is: "+search+"\n mid is "+mid+" index \n high is: "+high+" \n low is: "+low);
				if (search == array[mid]){
					System.out.println(search+" Element found at "+mid+" index");
					break;
				}else if(search > array[mid]){
					low = mid+1;
				}else if(search < array[mid]){
					high = mid-1;
				}else
					System.out.println("Element not found in the array");
					
			}//end of loop
		}
		}
