package test;

//import tree.tree;

public class treee {
	public static void main (String arg[]) {

	int num=5;
	int fact=1;
	for(int i=num;i>0;i--) {
		fact=fact*i;
	}
	System.out.print("Factorial is "+fact);
	
	
	}
}
