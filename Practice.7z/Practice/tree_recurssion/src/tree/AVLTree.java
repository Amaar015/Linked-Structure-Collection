package tree;
public class AVLTree { 
		

			private int key,height;
			private AVLTree left,right;
			public static final AVLTree Nil=new AVLTree();
			private AVLTree() {
             left=this;
             right=this;
             height=-1;
//				setRight(this);
//				setLeft(getRight());
			}
			public AVLTree(int key) {
				this.key=key;
				this.left=Nil;
		        this.right=Nil;
			}
	private AVLTree(int key, AVLTree left, AVLTree right) {
//				super();
				this.key = key;
				this.left = left;
				this.right = right;
		height=1+ Math.max(left.height, right.height);
			}
			public int getKey() {
				return key;
			}
			public void setKey(int key) {
				this.key = key;
			}
			public AVLTree getLeft() {
				return left;
			}
			public void setLeft(AVLTree left) {
				this.left = left;
			}
			public AVLTree getRight() {
				return right;
			}
			public void setRight(AVLTree right) {
				this.right = right;
			}
			
			// Size Method
			
			public int size() {
				if(this==Nil) {
					return 0;
				}
				return 1+ left.size()+ right.size();
			}
			
			// Print Tree
			
			public String toString() {
				if(this==Nil) return "";
				return getLeft()+" "+getKey()+" "+getRight();
			}
			
			// Add Method
			
			public boolean add(int key) {
				int oldSize=size();
				grow(key);
				return size()>oldSize;
			}
			
			// Grow Method
			
			public AVLTree grow(int key) {
				if(this==Nil) {
					return new AVLTree(key);
				}
				if(key==this.getKey()) {
					return this;
				}
				if(key<this.getKey()) {
					setLeft(getLeft().grow(key));
				}
				else
				{
					setRight(getRight().grow(key));
				}
				reBalance();
				
height=1+Math.max(getLeft().height, getRight().height);
				return this;
			}
			
			// rotating tree to left side
			
//			public void rotateLeft() {
//		setLeft(new AVLTree(getKey(),getLeft(),getRight().getLeft()));
//				setKey(getRight().getKey());
//				setRight(getRight().getRight());
//			}
			
			private void rotateLeft() {
				left=new AVLTree(key,left,right.left);
				key=right.key;
				right=right.right;
			}
			// rotating tree to right side
			
//			public void rotateRight() {
//		setRight(new AVLTree(getKey(),getLeft().getRight(),getRight()));
//				setKey(getLeft().getKey());
//				setLeft(getLeft().getLeft());
//			}
			private void rotateRight() {
				right=new AVLTree(key,left.right,right);
				key=left.key;
				left=left.left;
			}
			// Balance Tree
			
			public void reBalance() {
		 		if(right.height>left.height+1) {
		 if(right.left.height>right.right.height) 
		 				right.rotateRight();
		 			
		 			rotateLeft();
		 		}
		 		
		 		 if (left.height>right.height+1) {
		if(left.right.height>left.left.height) 
		 				left.rotateLeft();
		 			rotateRight();
		 		}
		 	}
			
			
			
			public static void main(String[] args) {
                AVLTree tree =new AVLTree(15);
				System.out.println(tree);
				System.out.println(tree.size());
				tree.add(55);
				tree.add(14);
				tree.add(5);
				tree.add(64);
				
				tree.add(13);
                 	System.out.println(tree);
				System.out.println(tree.size());
			}
		}

