package tree;

import java.util.Scanner;

public class Recusion 
{
 
	public static void hanoi(int n,char source,char dest, char aux) 
	{
		if(n==1)
			System.out.println(source+"-->"+dest);
		else 
		{
			hanoi(n-1,source,aux,dest);
			System.out.println(source+"-->"+dest);
			hanoi(n-1,aux,dest,source);
		}
	}
	
	public static void main(String arg[]) 
	{   
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter number of disk: ");
		int n = scanner.nextInt();
		hanoi(n,'A','C','B');
	}
	
}
