package tree;



class tree01{
	Object root;
	tree01 left;
	tree01 right;
	
	public tree01(Object root) {
		this.root=root;
	}
	public tree01(Object root,tree01 left,tree01 right)
	{this.root=root;
	this.left=left;
	this.right=right;
	}
	
	public void setRoot(Object root) 
	{this.root=root;}
	public Object getRoot()
	{return root;}
	
	public void setLeft(tree01 left) {
		this.left=left;
	}
	
	public tree01 getLeft() {
		return right;
	}
	public void setRight(tree01 right) {
		this.right=right;
	}
	
	public tree01 getRight() {
		return right;
	}
	
///	post Expression
	
	public String toString() {
		StringBuffer buf=new StringBuffer("");
		if(left!=null)
			buf.append(left+",");
		if(right!=null)
			buf.append(right+",");
		buf.append(" "+root);
		return buf+" ";
		
	}
	public boolean isleaf() {
		if(left==null && right==null)
			return true;
		else
			return false;
	}
	
	public int size() {
		 if(left==null&& right==null)
			 return 1;
		 if(left==null)
			 return 1+right.size();
		 if(right==null)
			 return 1+left.size();
		 return 1+left.size()+right.size();
	}
	
	// depth is same thing in tree
	public int height() {
		if(root==null)
			return -1;
		int leftn=0;
		int rightn=0;
		if(left!=null)
		leftn=1+left.height();
		if(right!=null)
			rightn=1+right.height();
		return leftn>rightn?leftn:rightn;
	}
	
	public boolean contains(Object t) {
		if(root==t)
			return true;
		boolean present=false;
		if(left!=null) {
			if(left.toString().contains(t.toString()))
				return true;
		present=left.contains(t);}
		
		if(right!=null) {
			if(right.toString().contains(t.toString()))
				return true;
			present=right.contains(t);
		}
		return present;
		
	}
	
	
	
	
}

public class tree10 {

	public static void main(String arg[]) {
		tree01 t1=new tree01("A");
		tree01 t2=new tree01("B");
		tree01 t3=new tree01("C");
		tree01 t4=new tree01("D");
		tree01 t5=new tree01("E");
		tree01 t6=new tree01(1);
		tree01 t7=new tree01(3);
		
		t3.setLeft(t4);
		t3.setRight(t5);
		
		t1.setLeft(t2);
		t1.setRight(t3);
		System.out.println(t1);
		System.out.println(t1.size());
		System.out.println(t1.isleaf());
		System.out.println(t1.height());
		System.out.println(t1.contains(1));
		
	}
	
}
