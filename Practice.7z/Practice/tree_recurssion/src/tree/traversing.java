package tree;


class binary_tree{
	Object root;
	binary_tree left;
	binary_tree right;
	
	public binary_tree(Object root) {
		this.root=root;
	}
	public binary_tree(Object root,binary_tree left,binary_tree right) {
		this.root=root;
		this.left=left;
		this.right=right;
	}
	public void setroot(Object root) {
		this.root=root;
	}
	public Object getroot() {
		return root;
	}
	public void setleft_root(binary_tree left) {
		this.left=left;
	}
	public binary_tree getleft() {
		return left;
	}
	public void setright_root(binary_tree right) {
		this.right=right;
	}
	public binary_tree getright() {
		return right;
	}
	
	public String toString() {
		StringBuffer buf=new StringBuffer("");
		buf.append(root+",");
		if(left!=null)
			buf.append(left+"");
		
		if(right!=null)
			buf.append(""+right);
		return buf+"";
	}
	public boolean isleaf() {
		if(left==null && right==null)
			return true;
		else
			return false;
	}
	
	public int size() {
		if(left==null&& right==null) 
			return 1;
		if(left==null) return 1+right.size();
		if(right==null) return 1+left.size();
		return 1+left.size()+right.size();

	}
	
	public int height() {
		if(root==null)
			return -1;
		int leftn=0;
		int rightn=0;
		if(left!=null)
			leftn=1+left.height();
		if(right!=null)
			rightn=1+right.height();
			return leftn>rightn?leftn:rightn;
	}

	int deg=0;
	public int degree() {
		if(this.getroot()==null)
			return 0;
		if(this.getleft()==null) {
			this.getright().degree();
		   deg++;
		}
		if(this.getright()==null) {
			this.getleft().degree();
			deg++;
		}
		return deg;
	}

	public int minvalue(binary_tree ro) {
		int minval=ro.getroot();
	     while(root.getleft()!=null)
	    	 minval=root.getleft().getroot();
		root=root.getleft();
		
	}
	
	
	
	public boolean contains(Object t) {
		if(root==t) 
			return true;
		boolean present=false;
		if(left!=null) {
			if(left.toString().contains(t.toString()))
				return true;
			present=left.contains(t);
		}
		if(right!=null) {
			if(right.toString().contains(t.toString()))
				return true;
			present=right.contains(t);
			
		}
		return present;
	}
	
	public boolean isfull(){
		int height=height();
		int size=size();
//		System.out.println(height);
//		int match=(int)Math.pow(2,height+1);
		
		int match=2*(height+1);
		match--;
		System.out.print("Size="+size+" height ="+match);
		return (match==size);
	}
	
	public void swap() {
		if(left==null || right==null) {
			System.out.println("Swaping is not possible");
			return;
		}
		binary_tree temp=left;
		left=right;
		right=temp;
	}
	
	public binary_tree Right_most_left() {
		if(root==null)
			return null;
		if(left!=null)
for(binary_tree i=left;i!=null; i=i.getright()) {
       if(i.getright()==null)
    	   return i;
	
			}
	  return null;
	}
	
	public binary_tree left_most_right() {
		if(root==null)
			return null;
		if(right!=null)
			for(binary_tree i=right;i!=null;i=i.getleft()) {
				if(i.getleft()==null)
					return i;
			}
	
	return null;
	}
	
	
	
}
public class traversing {

	public static void main(String arg[]) {
		binary_tree t1=new binary_tree("A");
		binary_tree t2=new binary_tree("B");
		binary_tree t3=new binary_tree("C");
		binary_tree t4=new binary_tree("D");
		binary_tree t5=new binary_tree("E");
		
		
		t3.setleft_root(t4);
		t3.setright_root(t5);
		
		t1.setleft_root(t2);
		t1.setright_root(t3);
		System.out.println(t1);
		System.out.println(t1.size());
		System.out.println(t2.isleaf());
		System.out.println(t1.height());
		System.out.println(t1.contains("k"));
		System.out.println(t1.isfull());
		t1.swap();
		System.out.println(t1);
		System.out.println("Right most of left tree is"+t1.left_most_right());
		System.out.println("Right most of right tree is"+t1.Right_most_left());
	}
	
}
