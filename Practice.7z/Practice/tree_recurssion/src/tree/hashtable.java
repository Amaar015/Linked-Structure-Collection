package tree;




class country{

	public String name;
	public String language;
	public int area;
	public int population;
	
	public country(String name,String language,int area,int population) {
		this.name=name;
		this.language=language;
		this.area=area;
		this.population=population;
	}
	
	public String toString() {
		String str="";
		str=" name:"+name+" \n Language: "+language+"\n Area: "+area+"\n "
				+ "Population: "+population;
	return str;
	}
	
	
}



public class hashtable  {

	

	private entry[] entries=new entry[11];
    private int size;
    
    private class entry{
    	Object key,value;
    	entry(Object k,Object v){
    		 key=k;
    		 value=v;
    	}
    	
    }
    public int hash(Object key) {
		return (key.hashCode() & 0x7FFFFFFF) % entries.length;
    }
    
    public int size() {
    	return size;
    }
    public void put(Object key,Object value) {
    	entries[hash(key)]=new entry(key,value);
    	size++;
    	
    }
    public Object get(Object key) {
    	return entries[hash(key)].value;
    }
    
    public Object remove(Object key) {
    	int h=hash(key);
    	Object value=entries[h].value;
    	entries[h]=null;
    	return value;
    }

		public static void main(String[] args) {
			country c1=new country("Pakistan","Urdu",881913,221);
			country c2=new country("Sri-Lanka","Tamil",65610,216);
			country c3=new country("United States","English",3531905,321);
			country c4=new country("United Kingdom","English",93628,67);
			country c5=new country("Portugal","Portugese",92090,10); 
			hashtable hash=new hashtable();
			hash.put("PK", c1);
			hash.put("SL", c2);
			hash.put("US", c3);
			hash.put("GB", c4);
			hash.put("PT", c5);
			hash.remove("PK");
			System.out.println(hash.size());
			System.out.println(hash.get("SL"));
			System.out.println(hash.get("GB"));
//			System.out.println("{"+hash.get("PK")+"}");
			System.out.println(hash.get("PT"));
//			hash.toString();
		}
	}


