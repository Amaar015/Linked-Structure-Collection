package tree;





	class Tree1{
		Object root;
		Tree1 left;
		Tree1 right;
		
		public Tree1(Object root) {
			this.root=root;
		}
		public Tree1(Object root,Tree1 left,Tree1 right) {
			this.root=root;
			this.left=left;
			this.right=right;
		}
		public void setroot(Object root) {
			this.root=root;
		}
		public Object getroot() {
			return root;
		}
		public void setleft_root(Tree1 left) {
			this.left=left;
		}
		public Tree1 getleft() {
			return left;
		}
		public void setright_root(Tree1 right) {
			this.right=right;
		}
		public Tree1 getright() {
			return right;
		}
	 
		
		 //level Order
//		public String toString() {
//			StringBuffer buf=new StringBuffer("");
//			buf.append(root);
//			
//			if(left!=null)
//				buf.append(left+",");
//			
//			if(right!=null)
//				buf.append(","+right);
//			return buf+"";
//		}
	  //          in order(left,root ,right)
//		public String toString() {
//			StringBuffer buf=new StringBuffer("");
//			if(left!=null)
//				buf.append(left+" ");
//			buf.append(root+" ");
//			if(right!=null)
//				buf.append(" "+right);
//			return buf+" ";
//		}
		        // pre(root,left , right)//
	       public String toString() {
	    	   StringBuffer buf=new StringBuffer("");
	    	   buf.append(root+" ");
	    	   if(left!=null)
	    		   buf.append(left+" ");
	    	   if(right!=null)
	    		buf.append(" "+right);
	    	   
	    	   return buf+"";
	       }
		
		
	       
		
		
		
		public boolean isleaf() {
				return (left==null && right==null); }
		public boolean isroot() {
			return 	(left!=null && right!=null);
		}
		
		public int size() {
			if(left==null&& right==null) 
				return 1;
			if(left==null) return 1+right.size();
			if(right==null) return 1+left.size();
			return 1+left.size()+right.size();

		}
		
		public int height() {
			if(root==null)
				return -1;
			int leftn=0;
			int rightn=0;
			if(left!=null)
				leftn=1+left.height();
			if(right!=null)
				rightn=1+right.height();
				return leftn>rightn?leftn:rightn;
		}
		
		public boolean contains(Object t) {
			if(root==t) 
				return true;
			if(left!=null) {
				if(left.contains(t))
					return true;
			}
			if(right!=null) {
				if(right.contains(t))
					return true;
				
			}
			return false;
		}
	}
	public class binarysearchtree{

	public static void main(String arg[]) {
		Tree1 t1=new Tree1("A");	
		Tree1 t2=new Tree1("B");	
		Tree1 t3=new Tree1("C");	
		Tree1 t4=new Tree1("D");	
		Tree1 t5=new Tree1("E");

		
		t3.setleft_root(t4);
		t3.setright_root(t5);
		
		
		t1.setleft_root(t2);
		t1.setright_root(t3);
//		t1=new Tree("A");
		System.out.println(t1);
		 System.out.println(t1.isroot());
		System.out.println( t1.contains("H"));
		System.out.println( t1.size());
		System.out.println( t1.height());
		
	}
	}


