package tree;


class Tree{
	Object root;
	Tree left;
	Tree right;
	
	public Tree(Object root) {
		this.root=root;
	}
	public Tree(Object root,Tree left,Tree right) {
		this.root=root;
		this.left=left;
		this.right=right;
	}
	public void setroot(Object root) {
		this.root=root;
	}
	public Object getroot() {
		return root;
	}
	public void setleft_root(Tree left) {
		this.left=left;
	}
	public Tree getleft() {
		return left;
	}
	public void setright_root(Tree right) {
		this.right=right;
	}
	public Tree getright() {
		return right;
	}
 
	
	 //In orders
//	public String toString() {
//		StringBuffer buf=new StringBuffer("");
//		buf.append(root);
//		
//		if(left!=null)
//			buf.append(left+",");
//		
//		if(right!=null)
//			buf.append(","+right);
//		return buf+"";
//	}
  //          level order(left,root ,right)
	public String toString() {
		StringBuffer buf=new StringBuffer("");
		if(left!=null)
			buf.append(left+" ");
		buf.append(root+" ");
		if(right!=null)
			buf.append(" "+right);
		return buf+" ";
	}
	        // pre(root,left , right)//
//       public String toString() {
//    	   StringBuffer buf=new StringBuffer("");
//    	   buf.append(root+" ");
//    	   if(left!=null)
//    		   buf.append(left+" ");
//    	   if(right!=null)
//    		buf.append(" "+right);
//    	   
//    	   return buf+"";
//       }
	
	
       
	
	
	
	public boolean isleaf() {
		if(left==null && right==null)
			return true;
		else
			return false;
	}
	
	public int size() {
		if(left==null&& right==null) 
			return 1;
		if(left==null) return 1+right.size();
		if(right==null) return 1+left.size();
		return 1+left.size()+right.size();

	}
	
	public int height() {
		if(root==null)
			return -1;
		int leftn=0;
		int rightn=0;
		if(left!=null)
			leftn=1+left.height();
		if(right!=null)
			rightn=1+right.height();
			return leftn>rightn?leftn:rightn;
	}
	
	public boolean contains(Object t) {
		if(root==t) 
			return true;
		boolean present=false;
		if(left!=null) {
			if(left.toString().contains(t.toString()))
				return true;
			present=left.contains(t);
		}
		if(right!=null) {
			if(right.toString().contains(t.toString()))
				return true;
			present=right.contains(t);
			
		}
		return present;
	}
}
public class pre {
public static void main() {
	Tree t1=new Tree("A");	
	Tree t2=new Tree("B");	
	Tree t3=new Tree("C");	
	Tree t4=new Tree("D");	
	Tree t5=new Tree("E");

	
	t3.setleft_root(t4);
	t3.setright_root(t5);
	
	t1.setleft_root(t2);
	t1.setright_root(t3);
//	t1=new Tree("A");
	System.out.println(t1);
//	 System.out.print(t1.size());
////	System.out.println( t1.toString());
//	System.out.println( t1.height());
	
}
}
