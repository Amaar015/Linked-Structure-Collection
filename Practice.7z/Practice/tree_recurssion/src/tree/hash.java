package tree;

//import tree.hashtable.entry;
//
//class country{
//
//	public String name;
//	public String language;
//	public int area;
//	public int population;
//	
//	public country(String name,String language,int area,int population) {
//		this.name=name;
//		this.language=language;
//		this.area=area;
//		this.population=population;
//	}
//	
//	public String toString() {
//		String str="";
//		str=" name:"+name+" \n Language: "+language+"\n Area "+area+"\n "
//				+ "Population: "+population;
//	return str;
//	}
//	
//	
//}



public class hash  {

	Entry []entries;
	private int size;
	private final Entry Nill=new Entry(null,null);
	
	
	hash(int length){
		entries=new Entry[length];
	}
	
    hash() {
    	this(11);
    }
    
    private class Entry{
    	Object key,value;
    	
    	
    	Entry(Object key,Object value){
    		this.key=key;
    		this.value=value;
    	}
    }
         
    private int hashtable(Object key) {
		return (key.hashCode() & 0x7FFFFFFF) % entries.length;
    }
    
    public int size() {
    	return size;
    }
    
    public void put(Object key,Object value) {
    	if(size>0.7*entries.length)
    		rehash();
    	int h= hashtable(key);
    	for(int i=0;i<entries.length;i++) {
    		int j=(i+h)%entries.length;
    		if(entries[j]==null || entries[j]==Nill) {
    			entries[j]=new Entry(key,value);
    			size++;
    			break;
    		
    		}
    	}
    	
    }
    
    private void rehash() {
    	Entry[] oldEntries=entries;
    	entries=new Entry[2*oldEntries.length+1];
    	for(Entry entry:oldEntries) {
    		if(entry ==null && entry ==Nill)
    			continue;
    		int h=hashtable(entry.key);
    		for(int j=0;j<entries.length;j++) {
    			int k=(h+j)%entries.length;
    			if(entries[k]==null) {
    				entries[k]=entry;
    				break;
    			}
    		   }
    	      }
             }
    
    public Object get(Object key) {
    	int h=hashtable(key);
    	for(int i=0; i<entries.length;i++) {
    		int j=(h+i)%entries.length;
    	if(entries[j]==null) break;
    	if(entries[j]==Nill) continue;
    	if(entries[j].key.equals(key))
    		return entries[j].value;
    	}
    
    return null;
    }
    
    public Object remove(Object key) {
    	int h=hashtable(key);
    	for(int i=0; i<entries.length;i++) {
    		int j=(h+i)%entries.length;
    	if(entries[j]==null) break;
    	if(entries[j]==Nill) continue;
    	if(entries[j].key.equals(key)) {
    	Object value=entries[j].value;
    	entries[j]=Nill;
    	size--;
    	return value;
    	}
    	}
    
    return null;	
    }
    
    public static void main(String arg[]) {
    	hash Hash=new hash();
    	Hash.put("PK","Pakistan");
    	Hash.put("IND","India");
    	Hash.put("USA","America");
    	Hash.put("GB","United kingdom");
    	Hash.put("PT","portagual");
    	Hash.remove("GB");
    	System.out.println(Hash.get("PK"));
    	System.out.println(Hash.get("PT"));
    	System.out.println(Hash.get("USA"));
    	System.out.println(Hash.size());
    }
	
		}
	


