package test;
public interface Collections {

public boolean add(Object obj);
public void clear();
public boolean contains(Object obj);
public int size();
public boolean Isempty();
public boolean remove(Object obj);
public iterator Iterator();
}
