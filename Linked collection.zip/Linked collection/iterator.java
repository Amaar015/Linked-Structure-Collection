package test;

public interface iterator {
	  public boolean hasnext();
	  public Object next();
	  public void remove();
}
